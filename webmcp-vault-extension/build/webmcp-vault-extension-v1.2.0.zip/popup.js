const DEFAULT_VAULT_URL = 'http://127.0.0.1:7876';

const elAppVersion = document.getElementById('appVersion');
const elVaultDot = document.getElementById('vaultDot');
const elVaultStateText = document.getElementById('vaultStateText');
const elBtnTouchIdUnlock = document.getElementById('btnTouchIdUnlock');

const elTabBtnAccounts = document.getElementById('tabBtnAccounts');
const elTabBtnSettings = document.getElementById('tabBtnSettings');
const elPanelAccounts = document.getElementById('panelAccounts');
const elPanelSettings = document.getElementById('panelSettings');

const elVaultDomainLabel = document.getElementById('vaultDomainLabel');
const elVaultMatchCount = document.getElementById('vaultMatchCount');
const elVaultSearchInput = document.getElementById('vaultSearchInput');
const elVaultCandidateList = document.getElementById('vaultCandidateList');
const elVaultEmptyState = document.getElementById('vaultEmptyState');
const elBtnOpenInlineSelector = document.getElementById('btnOpenInlineSelector');
const elBtnGeneratePass = document.getElementById('btnGeneratePass');
const elGeneratedPassBox = document.getElementById('generatedPassBox');
const elGeneratedPassValue = document.getElementById('generatedPassValue');
const elBtnCopyGeneratedPass = document.getElementById('btnCopyGeneratedPass');

const elVaultUrlInput = document.getElementById('vaultUrlInput');
const elVaultPortBadge = document.getElementById('vaultPortBadge');
const elBtnTestVault = document.getElementById('btnTestVault');
const elBtnResetVault = document.getElementById('btnResetVault');
const elChkVaultAutosave = document.getElementById('chkVaultAutosave');
const elBtnSaveSettings = document.getElementById('btnSaveSettings');

const elToastMsg = document.getElementById('toastMsg');

let currentTab = null;
let currentVaultState = 'closed';
let cachedCandidates = [];
let globalSearchResults = [];
let searchDebounceTimer = null;
let searchSeq = 0;
let toastTimer = null;

function showToast(text, isError = false) {
  if (toastTimer) clearTimeout(toastTimer);
  elToastMsg.textContent = text || '';
  elToastMsg.className = isError ? 'toast error' : 'toast';
  if (text) {
    toastTimer = setTimeout(() => {
      elToastMsg.textContent = '';
      elToastMsg.className = 'toast';
    }, 2600);
  }
}

function sendPopupRequest(method, params = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'WEBMCP_VAULT_POPUP', method, params }, (res) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(res || { ok: false, error: 'No response' });
      }
    });
  });
}

function extractPortLabel(urlStr, fallback) {
  try {
    const u = new URL(urlStr);
    if (u.port) return u.port;
    return u.protocol === 'https:' || u.protocol === 'wss:' ? '443' : '80';
  } catch {
    return fallback;
  }
}

function renderVaultPill(vaultState, latencyMs) {
  currentVaultState = vaultState || 'closed';
  if (vaultState === 'open') {
    elVaultDot.className = 'dot open';
    elVaultStateText.textContent = latencyMs ? `Online · ${latencyMs}ms` : 'Online';
  } else if (vaultState === 'locked') {
    elVaultDot.className = 'dot connecting';
    elVaultStateText.textContent = 'Locked · Touch ID';
  } else {
    elVaultDot.className = 'dot closed';
    elVaultStateText.textContent = 'Offline';
  }
}

function switchTab(tabName) {
  const isAccounts = tabName === 'accounts';
  elTabBtnAccounts.classList.toggle('active', isAccounts);
  elTabBtnSettings.classList.toggle('active', !isAccounts);
  elPanelAccounts.classList.toggle('active', isAccounts);
  elPanelSettings.classList.toggle('active', !isAccounts);
}

elTabBtnAccounts.addEventListener('click', () => switchTab('accounts'));
elTabBtnSettings.addEventListener('click', () => switchTab('settings'));

let clipboardClearTimer = null;
async function copyTextWithToast(value, label, isSecret = false) {
  if (!value) {
    showToast(`No ${label} available`, true);
    return;
  }
  try {
    const str = String(value);
    await navigator.clipboard.writeText(str);
    if (isSecret || /pass|otp|2fa/i.test(label)) {
      if (clipboardClearTimer) clearTimeout(clipboardClearTimer);
      clipboardClearTimer = setTimeout(async () => {
        try {
          const cur = await navigator.clipboard.readText().catch(() => '');
          if (!cur || cur === str) await navigator.clipboard.writeText('');
        } catch {}
      }, 90000);
      showToast(`Copied ${label} (tự xóa sau 90s)`);
    } else {
      showToast(`Copied ${label}`);
    }
  } catch (err) {
    showToast(err.message || `Failed to copy ${label}`, true);
  }
}

async function resolveFullCandidate(item) {
  if (!item) return null;
  if (item.password || item.totpCode) return item;
  const res = await sendPopupRequest('vaultGetFillItem', { itemId: item.id });
  if (!res?.ok || !res?.candidate) {
    showToast(res?.error || 'Failed to load credential from Vault', true);
    return null;
  }
  return res.candidate;
}

function getCurrentHostLabel() {
  try {
    return currentTab?.url ? new URL(currentTab.url).hostname : '';
  } catch {
    return '';
  }
}

function mergePopupItems(localMatches, remoteItems) {
  const seen = new Set();
  return [...localMatches, ...remoteItems].filter((e) => e?.id && !seen.has(e.id) && seen.add(e.id));
}

function renderVaultCandidateItems(overrideList = null) {
  if (!elVaultCandidateList || !elVaultEmptyState) return;
  const q = (elVaultSearchInput?.value || '').trim().toLowerCase();
  const localMatches = cachedCandidates.filter((item) => {
    if (!q) return true;
    const hay = `${item.username || ''} ${item.title || ''} ${item.id || ''}`.toLowerCase();
    return hay.includes(q);
  });
  const filtered = Array.isArray(overrideList) ? overrideList : localMatches;

  if (elVaultMatchCount) {
    elVaultMatchCount.textContent = String(filtered.length);
  }

  elVaultCandidateList.textContent = '';
  if (filtered.length === 0) {
    elVaultEmptyState.style.display = 'block';
    return;
  }
  elVaultEmptyState.style.display = 'none';

  for (const item of filtered) {
    const row = document.createElement('div');
    row.className = 'vault-item';

    const top = document.createElement('div');
    top.className = 'vault-item-top';

    const info = document.createElement('div');
    info.style.minWidth = '0';

    const userEl = document.createElement('div');
    userEl.className = 'vault-item-user';
    userEl.textContent = item.username || item.title || item.id;

    const titleEl = document.createElement('div');
    titleEl.className = 'vault-item-title';
    titleEl.textContent =
      item.domainMatched === false && item.host
        ? `${item.host}${item.title && item.title !== item.host ? ' · ' + item.title : ''}`
        : (item.title || item.id);

    info.appendChild(userEl);
    info.appendChild(titleEl);
    top.appendChild(info);

    if (item.totpCode || item.hasOtp) {
      const otpPill = document.createElement('span');
      otpPill.className = 'vault-otp-pill';
      otpPill.textContent = item.totpCode ? `OTP ${item.totpCode}` : '2FA';
      top.appendChild(otpPill);
    }

    const actions = document.createElement('div');
    actions.className = 'vault-item-actions';

    const btnFill = document.createElement('button');
    btnFill.type = 'button';
    btnFill.className = 'primary';
    btnFill.textContent = 'Fill';
    btnFill.addEventListener('click', async () => {
      btnFill.disabled = true;
      const full = await resolveFullCandidate(item);
      if (!full) {
        btnFill.disabled = false;
        return;
      }
      const res = await sendPopupRequest('vaultFill', {
        tabId: currentTab?.id,
        action: 'fillCandidate',
        candidate: full,
      });
      btnFill.disabled = false;
      if (!res.ok) {
        showToast(res.error || 'Cannot fill on this page', true);
      } else {
        showToast(`Filled ${full.username || full.title}`);
      }
    });
    actions.appendChild(btnFill);

    if (item.username) {
      const btnUser = document.createElement('button');
      btnUser.type = 'button';
      btnUser.textContent = 'Copy User';
      btnUser.addEventListener('click', () => copyTextWithToast(item.username, 'Username'));
      actions.appendChild(btnUser);
    }

    if (item.password || item.hasPassword) {
      const btnPass = document.createElement('button');
      btnPass.type = 'button';
      btnPass.textContent = 'Copy Pass';
      btnPass.addEventListener('click', async () => {
        const full = await resolveFullCandidate(item);
        if (full) await copyTextWithToast(full.password, 'Password', true);
      });
      actions.appendChild(btnPass);
    }

    if (item.totpCode || item.hasOtp) {
      const btnOtp = document.createElement('button');
      btnOtp.type = 'button';
      btnOtp.textContent = 'Copy OTP';
      btnOtp.addEventListener('click', async () => {
        const full = await resolveFullCandidate(item);
        if (full) await copyTextWithToast(full.totpCode, '2FA OTP', true);
      });
      actions.appendChild(btnOtp);
    }

    row.appendChild(top);
    row.appendChild(actions);
    elVaultCandidateList.appendChild(row);
  }
}

async function loadRecentFallbackIfEmpty() {
  const hostLabel = getCurrentHostLabel();
  if ((elVaultSearchInput?.value || '').trim()) return;
  if (cachedCandidates.length > 0 || currentVaultState !== 'open') return;
  const seq = ++searchSeq;
  const res = await sendPopupRequest('vaultSearch', {
    query: '',
    url: currentTab?.url || '',
    limit: 15,
  });
  if (seq !== searchSeq || (elVaultSearchInput?.value || '').trim()) return;
  if (!res?.ok) {
    if (res?.locked) {
      renderVaultPill('locked');
      if (elVaultEmptyState) elVaultEmptyState.textContent = res.error || 'Vault is locked.';
    }
    return;
  }
  globalSearchResults = Array.isArray(res.items) ? res.items : [];
  if (globalSearchResults.length > 0 && elVaultDomainLabel) {
    elVaultDomainLabel.textContent = `Recent Vault Logins (0 on ${hostLabel || 'tab'})`;
  }
  renderVaultCandidateItems(globalSearchResults);
}

async function loadVaultCandidates() {
  if (!currentTab?.url) {
    cachedCandidates = [];
    globalSearchResults = [];
    if (elVaultDomainLabel) elVaultDomainLabel.textContent = 'Matching Logins';
    if (elVaultEmptyState) {
      elVaultEmptyState.textContent = 'Open an HTTP/HTTPS tab to view Vault accounts.';
    }
    renderVaultCandidateItems();
    await loadRecentFallbackIfEmpty();
    return;
  }

  const hostLabel = getCurrentHostLabel();
  if (elVaultDomainLabel) {
    elVaultDomainLabel.textContent = hostLabel ? `Logins · ${hostLabel}` : 'Matching Logins';
  }

  const res = await sendPopupRequest('vaultCandidates', {
    tabId: currentTab.id,
    url: currentTab.url,
  });

  if (!res.ok) {
    cachedCandidates = [];
    globalSearchResults = [];
    if (res.locked) renderVaultPill('locked');
    if (elVaultEmptyState) {
      elVaultEmptyState.textContent = res.error || 'Vault Kit offline or unreachable.';
    }
    renderVaultCandidateItems();
    return;
  }

  cachedCandidates = Array.isArray(res.candidates) ? res.candidates : [];
  globalSearchResults = [];
  if (elVaultEmptyState) {
    elVaultEmptyState.textContent = hostLabel
      ? `No matching credentials for ${hostLabel}.`
      : 'No matching credentials for this domain.';
  }
  if (cachedCandidates.length === 0 && !(elVaultSearchInput?.value || '').trim()) {
    await loadRecentFallbackIfEmpty();
    if (globalSearchResults.length > 0) return;
  }
  renderVaultCandidateItems();
}

async function refreshStatus({ hydrateInputs = false } = {}) {
  const res = await sendPopupRequest('status');
  if (!res.ok) {
    showToast(res.error || 'Failed to read status', true);
    return;
  }

  renderVaultPill(res.vaultState, res.vaultLatencyMs);
  currentTab = res.tab || null;

  if (hydrateInputs) {
    const vUrl = res.vaultUrl || DEFAULT_VAULT_URL;
    elVaultUrlInput.value = vUrl;
    elVaultPortBadge.textContent = extractPortLabel(vUrl, '7876');
    elChkVaultAutosave.checked = res.autosaveEnabled !== false;
  }
}

elVaultSearchInput?.addEventListener('input', () => {
  const q = (elVaultSearchInput.value || '').trim();
  if (searchDebounceTimer) {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = null;
  }
  const seq = ++searchSeq;
  const hostLabel = getCurrentHostLabel();
  if (!q) {
    if (cachedCandidates.length > 0) {
      if (elVaultDomainLabel) {
        elVaultDomainLabel.textContent = hostLabel ? `Logins · ${hostLabel}` : 'Matching Logins';
      }
      renderVaultCandidateItems();
    } else if (globalSearchResults.length > 0) {
      if (elVaultDomainLabel) {
        elVaultDomainLabel.textContent = `Recent Vault Logins (0 on ${hostLabel || 'tab'})`;
      }
      renderVaultCandidateItems(globalSearchResults);
    } else {
      renderVaultCandidateItems();
      loadRecentFallbackIfEmpty();
    }
    return;
  }

  if (elVaultDomainLabel) {
    elVaultDomainLabel.textContent = hostLabel ? `Logins · ${hostLabel}` : 'Matching Logins';
  }
  const qLower = q.toLowerCase();
  const localMatches = cachedCandidates.filter((item) =>
    `${item.username || ''} ${item.title || ''} ${item.id || ''}`.toLowerCase().includes(qLower)
  );
  if (localMatches.length > 0) {
    renderVaultCandidateItems(localMatches);
  }
  searchDebounceTimer = setTimeout(async () => {
    const res = await sendPopupRequest('vaultSearch', {
      query: q,
      url: currentTab?.url || '',
      limit: 30,
    });
    if (seq !== searchSeq) return;
    if (!res?.ok) {
      if (res?.locked) renderVaultPill('locked');
      if (elVaultEmptyState) {
        elVaultEmptyState.textContent = res?.error || 'Vault unreachable.';
      }
      renderVaultCandidateItems(localMatches);
      return;
    }
    const remoteItems = Array.isArray(res.items) ? res.items : [];
    const merged = mergePopupItems(localMatches, remoteItems);
    if (merged.length === 0 && elVaultEmptyState) {
      elVaultEmptyState.textContent = `No accounts matching "${q}".`;
    }
    renderVaultCandidateItems(merged);
  }, 120);
});

elBtnTouchIdUnlock?.addEventListener('click', async () => {
  elBtnTouchIdUnlock.disabled = true;
  elBtnTouchIdUnlock.textContent = '⏳ Touch ID...';
  const res = await sendPopupRequest('unlockTouchId', {
    reason: 'Mở khóa WebMCP Vault Companion',
  });
  elBtnTouchIdUnlock.disabled = false;
  elBtnTouchIdUnlock.textContent = '🔓 Touch ID';
  if (!res.ok) {
    showToast(res.error || 'Touch ID failed', true);
    return;
  }
  renderVaultPill('open', res.latencyMs);
  showToast('Đã xác thực Touch ID & mở khóa Vault!');
  await loadVaultCandidates();
  if ((elVaultSearchInput?.value || '').trim()) {
    elVaultSearchInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
});

elBtnGeneratePass?.addEventListener('click', async () => {
  elBtnGeneratePass.disabled = true;
  const res = await sendPopupRequest('generatePassword', {
    tabId: currentTab?.id,
    url: currentTab?.url,
    length: 20,
    fillTab: true,
    saveToVault: true,
  });
  elBtnGeneratePass.disabled = false;
  if (!res.ok || !res.password) {
    showToast(res.error || 'Failed to generate password', true);
    return;
  }
  if (elGeneratedPassBox && elGeneratedPassValue) {
    elGeneratedPassValue.textContent = res.password;
    elGeneratedPassBox.style.display = 'flex';
  }
  await copyTextWithToast(res.password, 'Mật khẩu mạnh', true);
  if (res.saved) {
    await loadVaultCandidates();
  }
});

elBtnCopyGeneratedPass?.addEventListener('click', () => {
  const val = elGeneratedPassValue?.textContent || '';
  if (val) copyTextWithToast(val, 'Mật khẩu mạnh', true);
});

elBtnOpenInlineSelector?.addEventListener('click', async () => {
  if (!currentTab?.id) return;
  const res = await sendPopupRequest('vaultFill', {
    tabId: currentTab.id,
    action: 'openSelector',
  });
  if (!res.ok) {
    showToast(res.error || 'Cannot open selector on this tab', true);
  } else {
    showToast('Opened inline Vault selector on page');
  }
});

elVaultUrlInput?.addEventListener('input', () => {
  elVaultPortBadge.textContent = extractPortLabel(
    elVaultUrlInput.value.split(',')[0].trim() || DEFAULT_VAULT_URL,
    '7876'
  );
});

document.getElementById('vaultPresetRow')?.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-preset-url]');
  if (!btn) return;
  const preset = btn.getAttribute('data-preset-url') || DEFAULT_VAULT_URL;
  elVaultUrlInput.value = preset;
  elVaultPortBadge.textContent = extractPortLabel(preset.split(',')[0].trim(), '7876');
  showToast('Selected preset: ' + btn.textContent);
});

elBtnTestVault?.addEventListener('click', async () => {
  const vaultUrl = elVaultUrlInput.value.trim() || DEFAULT_VAULT_URL;
  elBtnTestVault.disabled = true;
  const res = await sendPopupRequest('testVault', { vaultUrl });
  elBtnTestVault.disabled = false;
  if (!res.ok) {
    showToast(res.error || 'Invalid Vault URL', true);
    return;
  }
  renderVaultPill(res.vaultState, res.latencyMs);
  if (res.vaultState === 'open') {
    showToast(`Vault reachable (${res.latencyMs}ms)`);
  } else {
    showToast('Vault unreachable at ' + res.vaultUrl, true);
  }
});

elBtnResetVault?.addEventListener('click', () => {
  elVaultUrlInput.value = DEFAULT_VAULT_URL;
  elVaultPortBadge.textContent = '7876';
  showToast('Reset Vault URL input to default');
});

elBtnSaveSettings?.addEventListener('click', async () => {
  const vaultUrl = elVaultUrlInput.value.trim() || DEFAULT_VAULT_URL;
  const autosaveEnabled = Boolean(elChkVaultAutosave.checked);
  elBtnSaveSettings.disabled = true;
  const res = await sendPopupRequest('saveSettings', { vaultUrl, autosaveEnabled });
  elBtnSaveSettings.disabled = false;
  if (!res.ok) {
    showToast(res.error || 'Failed to save settings', true);
    return;
  }
  elVaultUrlInput.value = res.vaultUrl;
  elVaultPortBadge.textContent = extractPortLabel(res.vaultUrl, '7876');
  renderVaultPill(res.vaultState, res.latencyMs);
  showToast('Saved Vault Companion settings');
  await loadVaultCandidates();
  if ((elVaultSearchInput?.value || '').trim()) {
    elVaultSearchInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
});

document.addEventListener('DOMContentLoaded', async () => {
  try {
    const manifest = chrome.runtime.getManifest?.();
    if (manifest?.version) {
      elAppVersion.textContent = 'v' + manifest.version;
    }
  } catch {}
  await refreshStatus({ hydrateInputs: true });
  await loadVaultCandidates();
});
